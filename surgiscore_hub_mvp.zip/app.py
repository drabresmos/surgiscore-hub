from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, Integer, String, Float, Text, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker, relationship

DATABASE_URL = "sqlite:///./surgiscore.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

app = FastAPI(title="SurgiScore Hub", version="0.1.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    patient_code = Column(String(80), unique=True, index=True, nullable=False)
    name = Column(String(200), nullable=True)
    age = Column(Integer, nullable=True)
    sex = Column(String(20), nullable=True)
    weight = Column(Float, nullable=True)
    height = Column(Float, nullable=True)
    diagnosis = Column(String(250), nullable=True)
    operation = Column(String(250), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    results = relationship("ScoreResult", back_populates="patient", cascade="all, delete-orphan")


class ScoreResult(Base):
    __tablename__ = "score_results"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    score_name = Column(String(120), nullable=False)
    score_category = Column(String(120), nullable=False)
    input_data_json = Column(Text, nullable=False)
    numeric_result = Column(Float, nullable=True)
    risk_category = Column(String(120), nullable=True)
    interpretation = Column(Text, nullable=True)
    recommendation = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="results")


Base.metadata.create_all(bind=engine)


SCORES: Dict[str, Dict[str, Any]] = {
    "alvarado": {
        "name": "Alvarado Score",
        "category": "Appendicitis",
        "fields": [
            ("migration", "Migration of pain to RIF", 1),
            ("anorexia", "Anorexia", 1),
            ("nausea", "Nausea/vomiting", 1),
            ("tenderness", "RIF tenderness", 2),
            ("rebound", "Rebound pain", 1),
            ("fever", "Fever", 1),
            ("leukocytosis", "Leukocytosis", 2),
            ("neutrophilia", "Neutrophilia/left shift", 1),
        ],
    },
    "rcri": {
        "name": "Revised Cardiac Risk Index",
        "category": "Preoperative cardiac risk",
        "fields": [
            ("high_risk_surgery", "High-risk surgery", 1),
            ("ihd", "History of ischemic heart disease", 1),
            ("chf", "History of congestive heart failure", 1),
            ("cva", "History of cerebrovascular disease", 1),
            ("insulin", "Diabetes requiring insulin", 1),
            ("creatinine", "Creatinine > 2 mg/dL", 1),
        ],
    },
    "bisap": {
        "name": "BISAP Score",
        "category": "Acute pancreatitis",
        "fields": [
            ("bun", "BUN > 25 mg/dL", 1),
            ("mental", "Impaired mental status", 1),
            ("sirs", "SIRS present", 1),
            ("age", "Age > 60 years", 1),
            ("pleural", "Pleural effusion", 1),
        ],
    },
    "qsofa": {
        "name": "qSOFA",
        "category": "Sepsis / acute deterioration",
        "fields": [
            ("rr", "Respiratory rate ≥ 22/min", 1),
            ("mental", "Altered mentation", 1),
            ("sbp", "Systolic BP ≤ 100 mmHg", 1),
        ],
    },
    "gbS": {
        "name": "Glasgow-Blatchford Score",
        "category": "Upper GI bleeding",
        "numeric": True,
    },
    "asa": {
        "name": "ASA Physical Status",
        "category": "Preoperative risk",
        "asa": True,
    },
    "clavien": {
        "name": "Clavien-Dindo Classification",
        "category": "Postoperative complications",
        "clavien": True,
    },
}


def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def checkbox_score(score_key: str, form: Dict[str, Any]) -> Dict[str, Any]:
    score_def = SCORES[score_key]
    total = 0
    inputs = {}
    for key, label, points in score_def["fields"]:
        checked = key in form
        inputs[label] = checked
        if checked:
            total += points

    if score_key == "alvarado":
        if total <= 4:
            risk = "Unlikely appendicitis"
            rec = "Observe, reassess, and consider alternative diagnosis. Imaging if clinical concern persists."
        elif total <= 6:
            risk = "Possible appendicitis"
            rec = "Surgical review and ultrasound/CT depending on patient profile and resources."
        elif total <= 8:
            risk = "Probable appendicitis"
            rec = "Urgent surgical assessment; imaging may support decision, especially in equivocal cases."
        else:
            risk = "Very probable appendicitis"
            rec = "High clinical probability; manage as appendicitis unless another diagnosis is evident."
        interp = f"Alvarado score = {total}/10."
    elif score_key == "rcri":
        risk = "Low risk" if total == 0 else "Elevated risk" if total <= 2 else "High cardiac risk"
        rec = "Optimize cardiac status, review functional capacity, ECG/troponin plan as clinically indicated."
        interp = f"RCRI = {total}. Higher values indicate higher perioperative major cardiac event risk."
    elif score_key == "bisap":
        risk = "Lower risk" if total <= 2 else "High risk severe pancreatitis"
        rec = "If ≥3, consider high-dependency/ICU monitoring, aggressive early resuscitation, and close organ failure surveillance."
        interp = f"BISAP = {total}/5."
    elif score_key == "qsofa":
        risk = "Higher risk of poor outcome" if total >= 2 else "Lower qSOFA risk"
        rec = "If ≥2, escalate assessment for sepsis/organ dysfunction and calculate full SOFA when possible."
        interp = f"qSOFA = {total}/3."
    else:
        risk = "Calculated"
        rec = "Use with clinical judgment."
        interp = f"Score = {total}."

    return {
        "numeric_result": total,
        "risk_category": risk,
        "interpretation": interp,
        "recommendation": rec,
        "inputs": inputs,
    }


def calculate_gbs(form: Dict[str, Any]) -> Dict[str, Any]:
    bun = float(form.get("bun", 0) or 0)
    hb = float(form.get("hb", 0) or 0)
    sex = form.get("sex", "male")
    sbp = int(form.get("sbp", 999) or 999)
    pulse = int(form.get("pulse", 0) or 0)
    melena = "melena" in form
    syncope = "syncope" in form
    liver = "liver" in form
    heart = "heart" in form

    total = 0
    if 18.2 <= bun < 22.4:
        total += 2
    elif 22.4 <= bun < 28:
        total += 3
    elif 28 <= bun < 70:
        total += 4
    elif bun >= 70:
        total += 6

    if sex == "male":
        if 12 <= hb < 13:
            total += 1
        elif 10 <= hb < 12:
            total += 3
        elif hb < 10:
            total += 6
    else:
        if 10 <= hb < 12:
            total += 1
        elif hb < 10:
            total += 6

    if 100 <= sbp < 110:
        total += 1
    elif 90 <= sbp < 100:
        total += 2
    elif sbp < 90:
        total += 3
    if pulse >= 100:
        total += 1
    if melena:
        total += 1
    if syncope:
        total += 2
    if liver:
        total += 2
    if heart:
        total += 2

    if total == 0:
        risk = "Very low risk"
        rec = "May be suitable for outpatient management if clinically stable and local policy allows."
    elif total <= 5:
        risk = "Low-intermediate risk"
        rec = "Usually requires endoscopic planning based on clinical picture."
    else:
        risk = "High risk"
        rec = "Admit, resuscitate, arrange urgent endoscopy according to severity and guidelines."

    inputs = {"BUN mg/dL": bun, "Hemoglobin g/dL": hb, "Sex": sex, "SBP": sbp, "Pulse": pulse,
              "Melena": melena, "Syncope": syncope, "Liver disease": liver, "Heart failure": heart}
    return {"numeric_result": total, "risk_category": risk, "interpretation": f"GBS = {total}.", "recommendation": rec, "inputs": inputs}


def calculate_asa(form: Dict[str, Any]) -> Dict[str, Any]:
    asa = int(form.get("asa_class", 1))
    emergency = "emergency" in form
    labels = {
        1: "Normal healthy patient",
        2: "Mild systemic disease",
        3: "Severe systemic disease",
        4: "Severe systemic disease that is a constant threat to life",
        5: "Moribund patient not expected to survive without operation",
        6: "Declared brain-dead organ donor",
    }
    risk = f"ASA {asa}{'E' if emergency else ''}"
    rec = "Document ASA class, optimize comorbidities, and communicate anesthetic risk."
    return {"numeric_result": asa, "risk_category": risk, "interpretation": labels.get(asa, "ASA class"), "recommendation": rec, "inputs": {"ASA class": asa, "Emergency": emergency}}


def calculate_clavien(form: Dict[str, Any]) -> Dict[str, Any]:
    grade = form.get("grade", "I")
    labels = {
        "I": "Deviation from normal course without pharmacological/surgical/endoscopic/radiological intervention.",
        "II": "Requires pharmacological treatment beyond allowed grade I drugs or blood transfusion/TPN.",
        "IIIa": "Intervention without general anesthesia.",
        "IIIb": "Intervention under general anesthesia.",
        "IVa": "Single-organ life-threatening complication requiring ICU.",
        "IVb": "Multi-organ life-threatening complication requiring ICU.",
        "V": "Death of patient.",
    }
    return {"numeric_result": None, "risk_category": f"Grade {grade}", "interpretation": labels.get(grade, "Complication grade"), "recommendation": "Save as postoperative morbidity documentation.", "inputs": {"Grade": grade}}


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    db = SessionLocal()
    patients = db.query(Patient).order_by(Patient.created_at.desc()).limit(10).all()
    results = db.query(ScoreResult).order_by(ScoreResult.created_at.desc()).limit(10).all()
    db.close()
    return templates.TemplateResponse("dashboard.html", {"request": request, "patients": patients, "results": results})


@app.get("/patients/new", response_class=HTMLResponse)
def new_patient(request: Request):
    return templates.TemplateResponse("patient_form.html", {"request": request})


@app.post("/patients/new")
def create_patient(
    patient_code: str = Form(...), name: str = Form(""), age: int | None = Form(None), sex: str = Form(""),
    weight: float | None = Form(None), height: float | None = Form(None), diagnosis: str = Form(""),
    operation: str = Form(""), notes: str = Form(""),
):
    db = SessionLocal()
    patient = Patient(patient_code=patient_code, name=name, age=age, sex=sex, weight=weight, height=height,
                      diagnosis=diagnosis, operation=operation, notes=notes)
    db.add(patient)
    db.commit()
    db.refresh(patient)
    db.close()
    return RedirectResponse(f"/patients/{patient.id}", status_code=303)


@app.get("/patients/{patient_id}", response_class=HTMLResponse)
def patient_detail(request: Request, patient_id: int):
    db = SessionLocal()
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    db.close()
    return templates.TemplateResponse("patient_detail.html", {"request": request, "patient": patient, "scores": SCORES})


@app.get("/patients/{patient_id}/score/{score_key}", response_class=HTMLResponse)
def score_form(request: Request, patient_id: int, score_key: str):
    db = SessionLocal()
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    db.close()
    return templates.TemplateResponse("score_form.html", {"request": request, "patient": patient, "score_key": score_key, "score": SCORES[score_key]})


@app.post("/patients/{patient_id}/score/{score_key}", response_class=HTMLResponse)
async def calculate_score(request: Request, patient_id: int, score_key: str):
    form_data = await request.form()
    form = dict(form_data)

    if score_key == "gbS":
        calculated = calculate_gbs(form)
    elif score_key == "asa":
        calculated = calculate_asa(form)
    elif score_key == "clavien":
        calculated = calculate_clavien(form)
    else:
        calculated = checkbox_score(score_key, form)

    db = SessionLocal()
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    result = ScoreResult(
        patient_id=patient_id,
        score_name=SCORES[score_key]["name"],
        score_category=SCORES[score_key]["category"],
        input_data_json=json.dumps(calculated["inputs"], ensure_ascii=False),
        numeric_result=calculated["numeric_result"],
        risk_category=calculated["risk_category"],
        interpretation=calculated["interpretation"],
        recommendation=calculated["recommendation"],
    )
    db.add(result)
    db.commit()
    db.refresh(result)
    db.close()
    return RedirectResponse(f"/results/{result.id}", status_code=303)


@app.get("/results/{result_id}", response_class=HTMLResponse)
def result_detail(request: Request, result_id: int):
    db = SessionLocal()
    result = db.query(ScoreResult).filter(ScoreResult.id == result_id).first()
    inputs = json.loads(result.input_data_json)
    db.close()
    return templates.TemplateResponse("result_detail.html", {"request": request, "result": result, "inputs": inputs})


@app.get("/search", response_class=HTMLResponse)
def search(request: Request, q: str = ""):
    db = SessionLocal()
    patients: List[Patient] = []
    if q:
        patients = db.query(Patient).filter(
            (Patient.patient_code.contains(q)) | (Patient.name.contains(q)) | (Patient.diagnosis.contains(q))
        ).order_by(Patient.created_at.desc()).all()
    db.close()
    return templates.TemplateResponse("search.html", {"request": request, "q": q, "patients": patients})
