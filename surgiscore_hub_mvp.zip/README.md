# SurgiScore Hub MVP

A local web app for general surgical scores with patient registry and saved score results.

## Included scores
- ASA Physical Status
- Alvarado Score
- Revised Cardiac Risk Index
- BISAP Score
- qSOFA
- Glasgow-Blatchford Score
- Clavien-Dindo Classification

## Run on macOS / Windows / Linux

```bash
cd surgiscore_hub
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

Open:

```text
http://127.0.0.1:8000
```

The SQLite database file `surgiscore.db` will be created automatically in the project folder.

## Notes
This is an MVP for clinical documentation support. It does not replace clinical judgment or local hospital guidelines.
